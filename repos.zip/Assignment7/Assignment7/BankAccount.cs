﻿using System;


namespace q7
{
    class BankAccount
    {
        public delegate void info();
        public double AccountNumber;
        public string Name;
        public double bankbalance;
        public void data()
        {
            Console.WriteLine("enter account number");
            AccountNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter name");
            Name = Console.ReadLine();
            Console.WriteLine("bank balance");
            bankbalance = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Account number={0}\nname={1}\nbank balance={2}", AccountNumber, Name, bankbalance);
            string filepath = @"C:\Users\Shama\OneDrive\Desktop\File\BankDetails.txt";
            StreamWriter sw = File.CreateText(filepath);
            sw.WriteLine("account number=" + AccountNumber);
            sw.WriteLine("name=" + Name);
            sw.WriteLine("bankbalance=" + bankbalance);
            sw.Close();

            Console.WriteLine("---data reading---");
            using (StreamReader sr = File.OpenText(filepath))

            {
                String s = "";

                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }



        }
        class filedata
        {
            public static void Main()
            {
                try
                {
                    BankAccount b = new BankAccount();
                    info d = new info(b.data);
                    d.Invoke();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.GetType().Name);
                }
            }
        }
    }
}
