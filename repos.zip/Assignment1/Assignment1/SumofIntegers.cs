﻿
namespace Qus3
{
    public class SumofIntegers
    {
        
        public static void Paramaaray()
        {
            try
            {
                int Sum = 0;
                Console.WriteLine("Enter the number of elements you want :");
                int no = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("-----------");
                int[] elements = new int[no];
                for (int i = 0; i < elements.Length; i++)
                {
                    elements[i] = Convert.ToInt32(Console.ReadLine());
                    Sum += elements[i];
                }
                Console.Write("The sum of integers is : {0}", Sum);
            }
            catch
            {
                Console.WriteLine("there is some exception");
            }
            

        }
        public static void Main()
        {
            SumofIntegers.Paramaaray();
        }
    }

    
}
