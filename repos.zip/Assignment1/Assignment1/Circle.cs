﻿

namespace Ques5
{
    public class Circle
    {
        public static void AreaCircumference()
        {
            double r, area;
            double PI = 3.14;
            Console.WriteLine("Enter the radius of circle :");
            r= Convert.ToDouble(Console.ReadLine());
            area = 2 * PI * r;
            Console.WriteLine("\nThe area of circle is {0} when radius is {1}", area, r);
            Console.WriteLine("\nThe circumference of circle is {0}", 2 * PI * r);
        }
        public static void Main()
        {
                Circle.AreaCircumference();
        }
    }
}
