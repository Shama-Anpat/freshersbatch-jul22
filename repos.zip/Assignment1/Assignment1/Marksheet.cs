﻿using System;

namespace Qus2
{
    public class Marksheet
    {
        public static void Main()
        {
            int i, highest,  sum = 0 ;
            double avg;

            int[] marks = new int[4];
            Console.WriteLine("Enter marks of 5 students : ");
            for (i = 0; i <4; i++)
            {
                //Console.WriteLine(i);
                marks[i] = Convert.ToInt32(Console.ReadLine());
                sum += marks[i];
            }
            avg = sum / marks.Length;
            highest = marks.Max();

            Console.Write("The sum of marks is : {0}\nThe Average of marks is : {1}\nThe highest is : {2}\n", sum, avg, highest);
            Console.ReadLine();
        }
    }
}
