﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ques4
{
    public class SwapNumbers
    {
        public void swap()
        {
            int temp;
            Console.WriteLine("Enter 1st number : ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter 2nd number : ");
            int b = Convert.ToInt32(Console.ReadLine());

            temp = a;
            a = b;
            b = temp;
            Console.Write("\nAfter Swapping : ");
            Console.Write("\nFirst Number : " + a);
            Console.Write("\nSecond Number : " + b);
        }
        public static void Main()
        {
            SwapNumbers swapNumbers = new SwapNumbers();
            swapNumbers.swap(); 
        }
    }
}
