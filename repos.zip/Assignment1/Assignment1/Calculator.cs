﻿using System;

namespace Qus1
{
    public class Calculator
    {
        public static void Main()
        {
            Console.WriteLine("Console Calculator in C#\r");
            Console.WriteLine("------------------------\n");

            Console.WriteLine("Type first number and press enter");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Type second number and press enter");
            int num2 = Convert.ToInt32(Console.ReadLine());

        Start:
            Console.WriteLine("Choose an option from the following list:");
            Console.WriteLine("\ta - Add");
            Console.WriteLine("\ts - Subtract");
            Console.WriteLine("\tm - Multiply");
            Console.WriteLine("\td - Divide");
            Console.Write("Your option? ");

            switch (Console.ReadLine())
            {
                case "a":
                    Console.WriteLine($"Your result : {num1} + {num2} = " + (num1 + num2));
                    break;

                case "s":
                    Console.WriteLine($"Your result : {num1} - {num2} = " + (num1 - num2));
                    break;

                case "m":
                    Console.WriteLine($"Your result : {num1} * {num2} = " + (num1 * num2));
                    break;

                case "d":
                    Console.WriteLine($"Your result : {num1} / {num2} = " + (num1 / num2));
                    break;

                default:
                    Console.WriteLine("Your choice {0} {1} is invalid ", num1, num2);
                    goto Start;
            }

        Decide:
            Console.WriteLine("Do you want to continue - Yes or No ?");
            string UserDescision = Console.ReadLine();

            switch (UserDescision.ToUpper())
            {
                case "YES":
                    goto Start;

                case "NO":
                    break;

                default:
                    Console.WriteLine("Your choice {0} is invalid. Please try again....");
                    goto Decide;
            }

            Console.Write("Press any key to close the Calculator console app...");
            Console.ReadLine();

        }
    }
}
